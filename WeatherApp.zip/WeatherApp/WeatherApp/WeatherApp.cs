﻿using Newtonsoft.Json.Linq; 
using System.IO;  

namespace WeatherApp
{
    public partial class WeatherApp : Form
    {
        //Enter the API Key copied from the Open Weather Map website
        private readonly string apiKey = "cb8abfa34403361dacc5bc8a5088a3b6";
        //Enter the API URL to get current weather information
        private readonly string apiUrl = "http://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}&units=metric";
        //Enter the API URL to get weather forecast information
        private readonly string forecastApiUrl = "http://api.openweathermap.org/data/2.5/forecast?q={0}&appid={1}&units=metric";

        //Save searched history
        private List<string> searchHistory = new List<string>();

        public WeatherApp()
        {
            InitializeComponent(); 
        }

        //Method to get current weather data from the API
        private async void GetWeatherData(string city)
        {
            //Create an HttpClient object to send HTTP requests
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    //Create the API URL with the city name and API Key
                    string url = string.Format(apiUrl, city, apiKey);

                    //Send a GET request to the API and receive the response
                    HttpResponseMessage response = await client.GetAsync(url);
                    //Check if the request was successful 
                    response.EnsureSuccessStatusCode();

                    //Read the data returned by the API (JSON string format)
                    string content = await response.Content.ReadAsStringAsync();

                    //Parse the JSON string to extract weather information
                    JObject json = JObject.Parse(content);

                    //Extract necessary information from the JSON
                    //Get the city name
                    string cityName = json["name"].ToString();
                    //Get the weather icon 
                    string iconCode = json["weather"][0]["icon"].ToString();
                    //Get the weather condition
                    string weatherDescription = json["weather"][0]["description"].ToString();
                    //Get the temperature (in Celsius)
                    double temperature = double.Parse(json["main"]["temp"].ToString());
                    //Get the humidity (%)
                    int humidity = int.Parse(json["main"]["humidity"].ToString());
                    //Get the wind speed (km/h)
                    double windSpeed = double.Parse(json["wind"]["speed"].ToString());
                    //Get the pressure
                    int pressure = int.Parse(json["main"]["pressure"].ToString());

                    //Get the sunrise time (timestamp format)
                    long sunriseTimestamp = long.Parse(json["sys"]["sunrise"].ToString());
                    //Get the sunset time (timestamp format)
                    long sunsetTimestamp = long.Parse(json["sys"]["sunset"].ToString());

                    //Convert the timestamp to a readable date-time format
                    DateTime sunrise = DateTimeOffset.FromUnixTimeSeconds(sunriseTimestamp).ToLocalTime().DateTime;
                    DateTime sunset = DateTimeOffset.FromUnixTimeSeconds(sunsetTimestamp).ToLocalTime().DateTime;

                    //Get the current time
                    DateTime searchTime = DateTime.Now;


                    //Assign the values retrieved from the API to Labels to display them on the UI
                    //Display the city name
                    lblCityName.Text = cityName;
                    //Display the search time
                    lblTime.Text = searchTime.ToString("dd/MM/yyyy HH:mm:ss");
                    //Display the temperature
                    lblTemperature.Text = temperature + "°C";
                    //Display the weather description
                    lblCondition.Text = weatherDescription;
                    //Display the humidity
                    lblHumidity.Text = humidity + "%";
                    //Display the wind speed
                    lblWindSpeed.Text = windSpeed + " km/h";
                    //Display the pressure
                    lblPressure.Text = pressure + " hPa";
                    //Display the sunrise time
                    lblSunrise.Text = sunrise.ToString("HH:mm");
                    //Display the sunset time
                    lblSunset.Text = sunset.ToString("HH:mm");

                    //Clear error messages if results are available
                    lblError.Text = "";

                    //Display the weather icon
                    //Enter the URL to download the weather icon
                    string iconUrl = $"http://openweathermap.org/img/wn/{iconCode}@2x.png";
                    //Create a new HttpClient object to download the icon
                    using (HttpClient imageClient = new HttpClient())
                    {
                        //Download the icon from the URL
                        var iconStream = await imageClient.GetStreamAsync(iconUrl);
                        //Set the icon in the PictureBox on the UI
                        pictureBoxWeatherIcon.Image = Image.FromStream(iconStream);
                    }
                }
                //Catch any errors that occur
                catch (Exception ex)
                {
                    //Display error messages on the UI
                    HandleError("Error: " + ex.Message);
                }
            }
        }

        //Method to handle errors and display error messages on the UI
        private void HandleError(string errorMessage)
        {
            //Display error messages in the error Label
            lblError.Text = errorMessage;
        }

        //Method to save search history to a text file
        private void SaveSearchHistory(string cityName, DateTime searchTime)
        {
            //Format the search history string
            string history = $"City searched: {cityName}, Time: {searchTime:dd/MM/yyyy hh:mm:ss tt}";
            //Log the saved content
            Console.WriteLine($"Saving history: {history}");
            //Add to the search history list
            searchHistory.Add(history);
            //Write to an external text file
            File.AppendAllText("searchHistory.txt", history + Environment.NewLine);
        }

        //Method to handle the event when the user clicks the search button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //Get the city name from the TextBox
            string city = txtCity.Text;
            //Check if the user has not entered a city name
            if (string.IsNullOrEmpty(city))
            {
                //Display the message "Please enter the name of the city."
                lblError.Text = "Please enter name of the city.";
                return;
            }
            //Call the method to fetch weather data from the API
            GetWeatherData(city);

            //Save the search history immediately after searching
            SaveSearchHistory(city, DateTime.Now);
        }

        //Change the background color of the TextBox when the user enters and leaves it
        private void txtCity_Enter(object sender, EventArgs e)
        {
            //Change the background color to light yellow when the user enters the TextBox
            txtCity.BackColor = System.Drawing.Color.LightYellow;
        }

        private void txtCity_Leave(object sender, EventArgs e)
        {
            //Restore the default background color when the user leaves the TextBox
            txtCity.BackColor = System.Drawing.Color.White;
        }

        //Method to get weather forecast information
        private async void GetWeatherForecast(string city)
        {
            //Two-dimensional array to store 5 forecast intervals, each with 3 pieces of information
            string[,] forecastData = new string[5, 3];
            //Use HttpClient to send HTTP requests
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    //Format the URL with the city name and API Key
                    string url = string.Format(forecastApiUrl, city, apiKey);
                    //Send a GET request to the API
                    HttpResponseMessage response = await client.GetAsync(url);
                    //Check if the request was successful
                    response.EnsureSuccessStatusCode();
                    //Read the response content as a string
                    string content = await response.Content.ReadAsStringAsync();
                    //Parse the JSON string into a JObject
                    JObject json = JObject.Parse(content);

                    //Loop through the first 5 forecast intervals
                    for (int i = 0; i < 5; i++)
                    {
                        //Retrieve forecast data at position i
                        var forecast = json["list"][i];
                        //Store temperature in the array
                        forecastData[i, 0] = $"Temp: {forecast["main"]["temp"]}°C";
                        //Store humidity in the array
                        forecastData[i, 1] = $"Humidity: {forecast["main"]["humidity"]}%";
                        //Store weather description in the array
                        forecastData[i, 2] = forecast["weather"][0]["description"].ToString();
                    }

                    //Clear the old list in the ListBox displaying the forecast
                    listBoxForecast.Items.Clear();
                    //Loop through 5 forecast intervals to display them on the UI
                    for (int i = 0; i < 5; i++)
                    {
                        //Add the forecast title to the ListBox
                        listBoxForecast.Items.Add($"Forecast {i + 1}:");
                        //Display each piece of information (temperature, humidity, description)
                        for (int j = 0; j < 3; j++)
                        {
                            //Add the information to the ListBox
                            listBoxForecast.Items.Add(forecastData[i, j]);
                        }
                        //Add a blank line between forecast intervals
                        listBoxForecast.Items.Add("");
                    }
                }
                //Catch any errors that occur
                catch (Exception ex)
                {
                    //Display error messages
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void lblTemperature_Click(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void lblHumidity_Click(object sender, EventArgs e)
        {

        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void btnRefreshForecast_Click(object sender, EventArgs e)
        {
            //Get the city name from the TextBox
            string city = txtCity.Text;
            //Check if the user has not entered a city name
            if (!string.IsNullOrEmpty(city))
            {
                //Call the method to fetch weather forecast information
                GetWeatherForecast(city);
            }
            else
            {
                //Display the message "Please enter name of the city to see forecast."
                MessageBox.Show("Please enter name of the city to see forecast.");
            }
        }

        private void lblHumidity_Click_1(object sender, EventArgs e)
        {

        }

        private void lbl1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCityName_Click(object sender, EventArgs e)
        {

        }

        private void lblTime_Click(object sender, EventArgs e)
        {

        }

        private void lblError_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxWeatherIcon_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lbl3_Click_1(object sender, EventArgs e)
        {

        }

        private void lbl4_Click(object sender, EventArgs e)
        {

        }

        private void lblSunrise_Click(object sender, EventArgs e)
        {

        }

        private void lbl5_Click(object sender, EventArgs e)
        {

        }

        private void lblSunset_Click(object sender, EventArgs e)
        {

        }

        private void lbl6_Click(object sender, EventArgs e)
        {

        }

        private void lblPressure_Click(object sender, EventArgs e)
        {

        }

        private void listBoxForecast_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBoxHistory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
