﻿using Newtonsoft.Json.Linq;
using System.IO;  // Dùng để thao tác với tệp tin

namespace WeatherApp
{
    public partial class Form1 : Form
    {
        private readonly string apiKey = "cb8abfa34403361dacc5bc8a5088a3b6"; 
        private readonly string apiUrl = "http://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}&units=metric"; 
        private readonly string forecastApiUrl = "http://api.openweathermap.org/data/2.5/forecast?q={0}&appid={1}&units=metric";

        // Mảng một chiều lưu lịch sử tìm kiếm
        private List<string> searchHistory = new List<string>();

        public Form1()
        {
            InitializeComponent(); // Khởi tạo các thành phần giao diện trên Form
            EnsureHistoryFileExists();
        }

        // Phương thức lấy dữ liệu thời tiết hiện tại từ API
        private async void GetWeatherData(string city)
        {
            using (HttpClient client = new HttpClient())  // Sử dụng HttpClient để gửi yêu cầu HTTP
            {
                try
                {
                    // Tạo URL API với tên thành phố và API Key 
                    string url = string.Format(apiUrl, city, apiKey);

                    // Gửi yêu cầu GET đến API và nhận phản hồi
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode(); // Đảm bảo yêu cầu thành công (mã trạng thái 2xx)

                    // Đọc dữ liệu trả về từ API (dạng chuỗi JSON)
                    string content = await response.Content.ReadAsStringAsync();

                    // Phân tích chuỗi JSON để lấy thông tin thời tiết
                    JObject json = JObject.Parse(content);
                    // Trích xuất các thông tin cần thiết từ JSON
                    string cityName = json["name"].ToString();  // Lấy tên thành phố
                    string iconCode = json["weather"][0]["icon"].ToString(); // Lấy mã icon
                    string weatherDescription = json["weather"][0]["description"].ToString();  // Lấy tình trạng thời tiết
                    double temperature = double.Parse(json["main"]["temp"].ToString());  // Lấy nhiệt độ (đơn vị Celsius)
                    int humidity = int.Parse(json["main"]["humidity"].ToString());  // Lấy độ ẩm (%)
                    double windSpeed = double.Parse(json["wind"]["speed"].ToString());  // Lấy tốc độ gió (km/h)
                    int pressure = int.Parse(json["main"]["pressure"].ToString()); // Lấy áp suất
                    long sunriseTimestamp = long.Parse(json["sys"]["sunrise"].ToString());
                    long sunsetTimestamp = long.Parse(json["sys"]["sunset"].ToString());

                    // Chuyển đổi từ timestamp sang giờ định dạng đọc được
                    DateTime sunrise = DateTimeOffset.FromUnixTimeSeconds(sunriseTimestamp).ToLocalTime().DateTime;
                    DateTime sunset = DateTimeOffset.FromUnixTimeSeconds(sunsetTimestamp).ToLocalTime().DateTime;

                    // Lấy thời gian hiện tại
                    DateTime searchTime = DateTime.Now;

                    // Hiển thị các thông tin lấy được lên giao diện người dùng
                    lblCityName.Text = cityName;
                    lblTemperature.Text = temperature + "°C";
                    lblCondition.Text = weatherDescription;
                    lblHumidity.Text = humidity + "%";
                    lblWindSpeed.Text = windSpeed + " km/h";
                    lblPressure.Text = pressure + " hPa"; // Hiển thị áp suất
                    lblSunrise.Text = sunrise.ToString("HH:mm");
                    lblSunset.Text = sunset.ToString("HH:mm");
                    lblTime.Text = searchTime.ToString("dd/MM/yyyy HH:mm:ss"); // Hiển thị thời gian 

                    lblError.Text = ""; // Xóa thông báo lỗi nếu có kết quả trả về

                    // Hiển thị icon thời tiết
                    string iconUrl = $"http://openweathermap.org/img/wn/{iconCode}@2x.png";
                    using (HttpClient imageClient = new HttpClient())
                    {
                        var iconStream = await imageClient.GetStreamAsync(iconUrl);
                        pictureBoxWeatherIcon.Image = Image.FromStream(iconStream);
                    }
                }
                catch (Exception ex)
                {
                    // Xử lý ngoại lệ khi có lỗi xảy ra, ví dụ như không kết nối được với API
                    HandleError("Error: " + ex.Message);
                }
            }
        }

        // Phương thức hiển thị thông tin thời tiết lên giao diện người dùng
        private void DisplayWeatherData(string cityName, double temperature, string weatherDescription)
        {
            // Gán các giá trị lấy được từ API vào các Label để hiển thị lên giao diện
            lblCityName.Text = "City: " + cityName;
            lblTemperature.Text = "Temperature: " + temperature + "°C";
            lblCondition.Text = "Condition: " + weatherDescription;
        }

        // Phương thức xử lý lỗi và hiển thị thông báo lỗi lên giao diện
        private void HandleError(string errorMessage)
        {
            lblError.Text = errorMessage; // Hiển thị thông báo lỗi vào Label lỗi
        }

        
        // Phương thức lưu lịch sử tìm kiếm vào tệp văn bản
        private void SaveSearchHistory(string cityName, DateTime searchTime)
        {
            string history = $"City searched: {cityName}, Time: {searchTime:dd/MM/yyyy hh:mm:ss tt}";
            Console.WriteLine($"Saving history: {history}"); // Kiểm tra nội dung được lưu
            searchHistory.Add(history); // Thêm vào danh sách
            File.AppendAllText("searchHistory.txt", history + Environment.NewLine); // Ghi vào tệp
        }

        private void EnsureHistoryFileExists()
        {
            string filePath = "searchHistory.txt";
            if (!File.Exists(filePath))
            {
                File.Create(filePath).Close(); // Tạo tệp trống
            }
        }

        // Phương thức xử lý sự kiện khi người dùng nhấn nút tìm kiếm
        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Lấy tên thành phố từ TextBox
            string city = txtCity.Text;

            // Kiểm tra xem người dùng có nhập tên thành phố hay không
            if (string.IsNullOrEmpty(city))
            {
                lblError.Text = "Please enter name of city."; // Hiển thị thông báo lỗi
                return;
            }

            // Gọi phương thức lấy dữ liệu thời tiết từ API
            GetWeatherData(city);
        }

        // Thay đổi màu nền của TextBox khi người dùng vào và rời khỏi TextBox
        private void txtCity_Enter(object sender, EventArgs e)
        {
            txtCity.BackColor = System.Drawing.Color.LightYellow;  // Thay đổi màu nền thành màu vàng nhạt khi người dùng vào TextBox
        }

        private void txtCity_Leave(object sender, EventArgs e)
        {
            txtCity.BackColor = System.Drawing.Color.White;  // Khôi phục màu nền ban đầu khi người dùng rời khỏi TextBox
        }

        //dự báo thời tiết
        private async void GetWeatherForecast(string city)
        {
            string[,] forecastData = new string[5, 3]; // Mảng lưu 5 khoảng dự báo thời tiết
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string url = string.Format(forecastApiUrl, city, apiKey);
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string content = await response.Content.ReadAsStringAsync();
                    JObject json = JObject.Parse(content);

                    // Lặp qua 5 thời điểm dự báo đầu tiên
                    for (int i = 0; i < 5; i++)
                    {
                        var forecast = json["list"][i];
                        forecastData[i, 0] = $"Temp: {forecast["main"]["temp"]}°C";
                        forecastData[i, 1] = $"Humidity: {forecast["main"]["humidity"]}%";
                        forecastData[i, 2] = forecast["weather"][0]["description"].ToString();
                    }

                    // Hiển thị dữ liệu trong ListBox
                    listBoxForecast.Items.Clear();
                    for (int i = 0; i < 5; i++)
                    {
                        listBoxForecast.Items.Add($"Forecast {i + 1}:");
                        for (int j = 0; j < 3; j++)
                        {
                            listBoxForecast.Items.Add(forecastData[i, j]);
                        }
                        listBoxForecast.Items.Add(""); // Thêm dòng trống giữa các dự báo
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void lblTemperature_Click(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void lblHumidity_Click(object sender, EventArgs e)
        {

        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void btnHistory_Click_1(object sender, EventArgs e)
        {
            listBoxHistory.Items.Clear(); // Xóa danh sách cũ trong ListBox

            string filePath = "searchHistory.txt"; // Đường dẫn tệp lịch sử
            if (File.Exists(filePath)) // Kiểm tra nếu tệp tồn tại
            {
                try
                {
                    // Đọc tất cả các dòng trong tệp và thêm vào ListBox
                    var historyLines = File.ReadAllLines(filePath);
                    foreach (var line in historyLines)
                    {
                        Console.WriteLine($"Read history: {line}"); // Kiểm tra nội dung đọc
                        listBoxHistory.Items.Add(line);
                    }
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"Unable to read the file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No history found!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnRefreshForecast_Click(object sender, EventArgs e)
        {
            string city = txtCity.Text;
            if (!string.IsNullOrEmpty(city))
            {
                GetWeatherForecast(city);
            }
            else
            {
                MessageBox.Show("Please enter name of city to see forecast.");
            }
        }
    }
}
