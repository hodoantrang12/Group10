﻿namespace WeatherApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            txtCity = new TextBox();
            btnSearch = new Button();
            lblCityName = new Label();
            lblTemperature = new Label();
            lblCondition = new Label();
            lblHumidity = new Label();
            lblWindSpeed = new Label();
            lblError = new Label();
            label1 = new Label();
            pictureBoxWeatherIcon = new PictureBox();
            lblPressure = new Label();
            lblSunrise = new Label();
            lblSunset = new Label();
            lblTime = new Label();
            lblWeatherCondition = new Label();
            lbl1 = new Label();
            lbl4 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            listBoxHistory = new ListBox();
            btnHistory = new Button();
            listBoxForecast = new ListBox();
            btnRefreshForecast = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxWeatherIcon).BeginInit();
            SuspendLayout();
            // 
            // txtCity
            // 
            txtCity.BackColor = Color.LightYellow;
            txtCity.Font = new Font("Microsoft New Tai Lue", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCity.Location = new Point(119, 70);
            txtCity.Name = "txtCity";
            txtCity.PlaceholderText = "Enter";
            txtCity.Size = new Size(341, 39);
            txtCity.TabIndex = 0;
            txtCity.Enter += txtCity_Enter;
            txtCity.Leave += txtCity_Leave;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Transparent;
            btnSearch.Font = new Font("Microsoft New Tai Lue", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Location = new Point(466, 68);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(117, 42);
            btnSearch.TabIndex = 1;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // lblCityName
            // 
            lblCityName.AutoSize = true;
            lblCityName.BackColor = Color.Transparent;
            lblCityName.Font = new Font("Microsoft New Tai Lue", 14F, FontStyle.Bold);
            lblCityName.ForeColor = Color.White;
            lblCityName.Location = new Point(44, 112);
            lblCityName.Name = "lblCityName";
            lblCityName.Size = new Size(76, 37);
            lblCityName.TabIndex = 2;
            lblCityName.Text = "City:";
            // 
            // lblTemperature
            // 
            lblTemperature.AutoSize = true;
            lblTemperature.BackColor = Color.Transparent;
            lblTemperature.Font = new Font("Microsoft New Tai Lue", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTemperature.ForeColor = Color.White;
            lblTemperature.Location = new Point(572, 112);
            lblTemperature.Name = "lblTemperature";
            lblTemperature.Size = new Size(182, 69);
            lblTemperature.TabIndex = 3;
            lblTemperature.Text = "Temp:";
            lblTemperature.Click += lblTemperature_Click;
            // 
            // lblCondition
            // 
            lblCondition.AutoSize = true;
            lblCondition.BackColor = Color.Transparent;
            lblCondition.Font = new Font("Microsoft New Tai Lue", 11F);
            lblCondition.ForeColor = Color.White;
            lblCondition.Location = new Point(154, 279);
            lblCondition.Name = "lblCondition";
            lblCondition.Size = new Size(52, 29);
            lblCondition.TabIndex = 4;
            lblCondition.Text = "N/A";
            lblCondition.Click += lbl1_Click;
            // 
            // lblHumidity
            // 
            lblHumidity.AutoSize = true;
            lblHumidity.BackColor = Color.Transparent;
            lblHumidity.Font = new Font("Microsoft New Tai Lue", 11F);
            lblHumidity.ForeColor = Color.White;
            lblHumidity.Location = new Point(508, 279);
            lblHumidity.Name = "lblHumidity";
            lblHumidity.Size = new Size(52, 29);
            lblHumidity.TabIndex = 5;
            lblHumidity.Text = "N/A";
            // 
            // lblWindSpeed
            // 
            lblWindSpeed.AutoSize = true;
            lblWindSpeed.BackColor = Color.Transparent;
            lblWindSpeed.Font = new Font("Microsoft New Tai Lue", 11F);
            lblWindSpeed.ForeColor = Color.White;
            lblWindSpeed.Location = new Point(826, 279);
            lblWindSpeed.Name = "lblWindSpeed";
            lblWindSpeed.Size = new Size(52, 29);
            lblWindSpeed.TabIndex = 6;
            lblWindSpeed.Text = "N/A";
            lblWindSpeed.Click += lbl3_Click;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.BackColor = Color.Transparent;
            lblError.Font = new Font("Microsoft New Tai Lue", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblError.ForeColor = Color.Red;
            lblError.Location = new Point(56, 183);
            lblError.Name = "lblError";
            lblError.Size = new Size(64, 32);
            lblError.TabIndex = 7;
            lblError.Text = "Error";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft New Tai Lue", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(44, 70);
            label1.Name = "label1";
            label1.Size = new Size(76, 37);
            label1.TabIndex = 8;
            label1.Text = "City:";
            // 
            // pictureBoxWeatherIcon
            // 
            pictureBoxWeatherIcon.BackColor = Color.Transparent;
            pictureBoxWeatherIcon.Location = new Point(475, 112);
            pictureBoxWeatherIcon.Name = "pictureBoxWeatherIcon";
            pictureBoxWeatherIcon.Size = new Size(91, 69);
            pictureBoxWeatherIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxWeatherIcon.TabIndex = 9;
            pictureBoxWeatherIcon.TabStop = false;
            // 
            // lblPressure
            // 
            lblPressure.AutoSize = true;
            lblPressure.BackColor = Color.Transparent;
            lblPressure.Font = new Font("Microsoft New Tai Lue", 11F);
            lblPressure.ForeColor = Color.White;
            lblPressure.Location = new Point(827, 418);
            lblPressure.Name = "lblPressure";
            lblPressure.Size = new Size(52, 29);
            lblPressure.TabIndex = 10;
            lblPressure.Text = "N/A";
            // 
            // lblSunrise
            // 
            lblSunrise.AutoSize = true;
            lblSunrise.BackColor = Color.Transparent;
            lblSunrise.Font = new Font("Microsoft New Tai Lue", 11F);
            lblSunrise.ForeColor = Color.White;
            lblSunrise.Location = new Point(180, 418);
            lblSunrise.Name = "lblSunrise";
            lblSunrise.Size = new Size(52, 29);
            lblSunrise.TabIndex = 11;
            lblSunrise.Text = "N/A";
            // 
            // lblSunset
            // 
            lblSunset.AutoSize = true;
            lblSunset.BackColor = Color.Transparent;
            lblSunset.Font = new Font("Microsoft New Tai Lue", 11F);
            lblSunset.ForeColor = Color.White;
            lblSunset.Location = new Point(518, 418);
            lblSunset.Name = "lblSunset";
            lblSunset.Size = new Size(52, 29);
            lblSunset.TabIndex = 12;
            lblSunset.Text = "N/A";
            // 
            // lblTime
            // 
            lblTime.AutoSize = true;
            lblTime.BackColor = Color.Transparent;
            lblTime.Font = new Font("Microsoft New Tai Lue", 14F, FontStyle.Bold);
            lblTime.ForeColor = Color.White;
            lblTime.Location = new Point(44, 146);
            lblTime.Name = "lblTime";
            lblTime.Size = new Size(90, 37);
            lblTime.TabIndex = 13;
            lblTime.Text = "Time:";
            // 
            // lblWeatherCondition
            // 
            lblWeatherCondition.AutoSize = true;
            lblWeatherCondition.BackColor = Color.Transparent;
            lblWeatherCondition.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            lblWeatherCondition.ForeColor = Color.White;
            lblWeatherCondition.Location = new Point(154, 247);
            lblWeatherCondition.Name = "lblWeatherCondition";
            lblWeatherCondition.Size = new Size(114, 29);
            lblWeatherCondition.TabIndex = 14;
            lblWeatherCondition.Text = "Condition";
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.BackColor = Color.Transparent;
            lbl1.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            lbl1.ForeColor = Color.White;
            lbl1.Location = new Point(508, 247);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(110, 29);
            lbl1.TabIndex = 15;
            lbl1.Text = "Humidity";
            lbl1.Click += lblHumidity_Click;
            // 
            // lbl4
            // 
            lbl4.AutoSize = true;
            lbl4.BackColor = Color.Transparent;
            lbl4.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            lbl4.ForeColor = Color.White;
            lbl4.Location = new Point(826, 250);
            lbl4.Name = "lbl4";
            lbl4.Size = new Size(138, 29);
            lbl4.TabIndex = 16;
            lbl4.Text = "Wind Speed";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(180, 386);
            label2.Name = "label2";
            label2.Size = new Size(88, 29);
            label2.TabIndex = 17;
            label2.Text = "Sunrise";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(518, 386);
            label3.Name = "label3";
            label3.Size = new Size(82, 29);
            label3.TabIndex = 18;
            label3.Text = "Sunset";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft New Tai Lue", 11F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(826, 386);
            label4.Name = "label4";
            label4.Size = new Size(102, 29);
            label4.TabIndex = 19;
            label4.Text = "Pressure";
            // 
            // listBoxHistory
            // 
            listBoxHistory.BackColor = Color.CornflowerBlue;
            listBoxHistory.Font = new Font("Microsoft New Tai Lue", 10F);
            listBoxHistory.FormattingEnabled = true;
            listBoxHistory.ItemHeight = 26;
            listBoxHistory.Location = new Point(475, 486);
            listBoxHistory.Name = "listBoxHistory";
            listBoxHistory.Size = new Size(522, 108);
            listBoxHistory.TabIndex = 20;
            // 
            // btnHistory
            // 
            btnHistory.BackColor = Color.CornflowerBlue;
            btnHistory.Font = new Font("Microsoft New Tai Lue", 10F);
            btnHistory.Location = new Point(357, 486);
            btnHistory.Name = "btnHistory";
            btnHistory.Size = new Size(112, 34);
            btnHistory.TabIndex = 21;
            btnHistory.Text = "History";
            btnHistory.UseVisualStyleBackColor = false;
            btnHistory.Click += btnHistory_Click_1;
            // 
            // listBoxForecast
            // 
            listBoxForecast.BackColor = Color.CornflowerBlue;
            listBoxForecast.BorderStyle = BorderStyle.FixedSingle;
            listBoxForecast.Font = new Font("Microsoft New Tai Lue", 10F);
            listBoxForecast.FormattingEnabled = true;
            listBoxForecast.ItemHeight = 26;
            listBoxForecast.Location = new Point(82, 486);
            listBoxForecast.Name = "listBoxForecast";
            listBoxForecast.Size = new Size(244, 80);
            listBoxForecast.TabIndex = 22;
            // 
            // btnRefreshForecast
            // 
            btnRefreshForecast.BackColor = Color.CornflowerBlue;
            btnRefreshForecast.Font = new Font("Microsoft New Tai Lue", 10F);
            btnRefreshForecast.Location = new Point(119, 572);
            btnRefreshForecast.Name = "btnRefreshForecast";
            btnRefreshForecast.Size = new Size(178, 34);
            btnRefreshForecast.TabIndex = 23;
            btnRefreshForecast.Text = "Refresh Forecast";
            btnRefreshForecast.UseVisualStyleBackColor = false;
            btnRefreshForecast.Click += btnRefreshForecast_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1058, 614);
            Controls.Add(btnRefreshForecast);
            Controls.Add(listBoxForecast);
            Controls.Add(btnHistory);
            Controls.Add(listBoxHistory);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lbl4);
            Controls.Add(lbl1);
            Controls.Add(lblWeatherCondition);
            Controls.Add(lblTime);
            Controls.Add(lblSunset);
            Controls.Add(lblSunrise);
            Controls.Add(lblPressure);
            Controls.Add(pictureBoxWeatherIcon);
            Controls.Add(label1);
            Controls.Add(lblError);
            Controls.Add(lblWindSpeed);
            Controls.Add(lblHumidity);
            Controls.Add(lblCondition);
            Controls.Add(lblTemperature);
            Controls.Add(lblCityName);
            Controls.Add(btnSearch);
            Controls.Add(txtCity);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBoxWeatherIcon).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCity;
        private Button btnSearch;
        private Label lblCityName;
        private Label lblTemperature;
        private Label lblCondition;
        private Label lblHumidity;
        private Label lblWindSpeed;
        private Label lblError;
        private Label label1;
        private PictureBox pictureBoxWeatherIcon;
        private Label lblPressure;
        private Label lblSunrise;
        private Label lblSunset;
        private Label lblTime;
        private Label lblWeatherCondition;
        private Label lbl1;
        private Label lbl4;
        private Label label2;
        private Label label3;
        private Label label4;
        private ListBox listBoxHistory;
        private Button btnHistory;
        private ListBox listBoxForecast;
        private Button btnRefreshForecast;
    }
}
